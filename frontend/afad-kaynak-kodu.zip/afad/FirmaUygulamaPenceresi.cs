﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace afad
{
    // Firma araç paneli: firmanın araç filosunu listeler ve yeni araç ekler.
    // Backend stok adedi değil, plakalı tekil araç tutar (POST /api/vehicles, GET /api/vehicles).
    public partial class FirmaUygulamaPenceresi : UygulamaFormu
    {
        private TextBox txtPlaka = null!;
        private TextBox txtMarka = null!;
        private TextBox txtModel = null!;
        private TextBox txtYil = null!;
        private TextBox txtKapasite = null!;
        private ComboBox cmbSehir = null!;
        private NumericUpDown nudEnlem = null!;
        private NumericUpDown nudBoylam = null!;
        private ComboBox cmbDurum = null!;
        private TextBox txtStokArama = null!;
        private Label lblStokOzet = null!;

        private List<Arac> araclar = new();
        private readonly DataTable aracTablosu = new();

        public FirmaUygulamaPenceresi()
        {
            InitializeComponent();

            aracTablosu.Columns.Add("Id", typeof(Guid));
            aracTablosu.Columns.Add("Plaka", typeof(string));
            aracTablosu.Columns.Add("Araç Türü", typeof(string));
            aracTablosu.Columns.Add("Marka / Model", typeof(string));
            aracTablosu.Columns.Add("Yıl", typeof(string));
            aracTablosu.Columns.Add("Kapasite (kişi)", typeof(string));
            aracTablosu.Columns.Add("Konum", typeof(string));
            aracTablosu.Columns.Add("Durum", typeof(string));

            SadeArayuzuOlustur();
            VeriYukleyiciAyarla(AraclariYukle, otomatikYenilemeSaniyesi: 30);
        }

        private void SadeArayuzuOlustur()
        {
            Tema.FormuHazirla(this, "Firma - Araç Filosu Yönetimi");

            // =========================================================
            // 1. ÜST BAR
            // =========================================================
            string ad = ApiIstemcisi.AktifKullanici?.Name ?? "Firma";
            Panel pnlUstBar = Tema.UstBarOlustur($"FİRMA | {ad}");

            btnFirmaCikis = Tema.Buton("Çıkış Yap", Tema.Tehlike, 120, 36);
            btnFirmaCikis.Click += btnFirmaCikis_Click;

            btnFirmaRezervasyonAc = Tema.Buton("Gelen Talepler", Tema.AnaVurgu, 165, 36);
            btnFirmaRezervasyonAc.Click += btnFirmaRezervasyonAc_Click;

            Tema.UstBarButonlariEkle(pnlUstBar, btnFirmaCikis, btnFirmaRezervasyonAc);

            // =========================================================
            // 2. SOL PANEL (ARAÇ EKLEME FORMU)
            // =========================================================
            Panel pnlSol = Tema.SolPanelOlustur("Filoya Araç Ekle");

            pnlSol.Controls.Add(Tema.AlanBasligi("Plaka", 20, 58));
            txtPlaka = Tema.MetinKutusu(20, 80, 278, "06 ABC 123");
            txtPlaka.CharacterCasing = CharacterCasing.Upper;
            pnlSol.Controls.Add(txtPlaka);

            pnlSol.Controls.Add(Tema.AlanBasligi("Araç Türü", 20, 118));
            cmbFirmaAracTuru = Tema.SecimKutusu(20, 140, 278);
            foreach (var tur in Etiketler.AracTurleri) cmbFirmaAracTuru.Items.Add(tur.Ad);
            cmbFirmaAracTuru.SelectedIndex = 0;
            pnlSol.Controls.Add(cmbFirmaAracTuru);

            pnlSol.Controls.Add(Tema.AlanBasligi("Marka", 20, 178));
            pnlSol.Controls.Add(Tema.AlanBasligi("Model", 165, 178));
            txtMarka = Tema.MetinKutusu(20, 200, 133, "isteğe bağlı");
            txtModel = Tema.MetinKutusu(165, 200, 133, "isteğe bağlı");
            pnlSol.Controls.Add(txtMarka);
            pnlSol.Controls.Add(txtModel);

            pnlSol.Controls.Add(Tema.AlanBasligi("Model Yılı", 20, 238));
            pnlSol.Controls.Add(Tema.AlanBasligi("Kapasite (kişi)", 165, 238));
            txtYil = Tema.MetinKutusu(20, 260, 133, "isteğe bağlı");
            txtKapasite = Tema.MetinKutusu(165, 260, 133, "isteğe bağlı");
            pnlSol.Controls.Add(txtYil);
            pnlSol.Controls.Add(txtKapasite);

            pnlSol.Controls.Add(Tema.AlanBasligi("Aracın Bulunduğu Konum", 20, 298));
            cmbSehir = Tema.SecimKutusu(20, 320, 278);
            nudEnlem = Tema.SayiKutusu(20, 358, 133, -90, 90, 4);
            nudBoylam = Tema.SayiKutusu(165, 358, 133, -180, 180, 4);
            pnlSol.Controls.Add(cmbSehir);
            pnlSol.Controls.Add(nudEnlem);
            pnlSol.Controls.Add(nudBoylam);
            Sehirler.SecimKutusunuBagla(cmbSehir, nudEnlem, nudBoylam);

            pnlSol.Controls.Add(Tema.AlanBasligi("Durum", 20, 398));
            cmbDurum = Tema.SecimKutusu(20, 420, 278);
            foreach (var d in Etiketler.AracDurumlariSecilebilir) cmbDurum.Items.Add(d.Ad);
            cmbDurum.SelectedIndex = 0;
            pnlSol.Controls.Add(cmbDurum);

            btnAracKaydet = Tema.Buton("Aracı Filoya Ekle", Tema.Basari, 278, 42);
            btnAracKaydet.Location = new Point(20, 466);
            btnAracKaydet.Click += btnAracKaydet_Click;
            pnlSol.Controls.Add(btnAracKaydet);

            // =========================================================
            // 3. SAĞ PANEL (ARAÇ LİSTESİ)
            // =========================================================
            Panel pnlSag = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(24, 18, 24, 8),
                BackColor = Tema.ArkaPlan
            };

            Panel pnlTabloUst = Tema.TabloUstBar("Araç Filom", out lblStokOzet);

            txtStokArama = new TextBox
            {
                Width = 200,
                Font = new Font("Segoe UI", 9.5F),
                BackColor = Tema.Panel,
                ForeColor = Tema.MetinAna,
                BorderStyle = BorderStyle.FixedSingle,
                PlaceholderText = "Plaka / Marka ara...",
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(pnlTabloUst.Width - 200, 8)
            };
            txtStokArama.TextChanged += (s, e) => ListeyiFiltrele();
            pnlTabloUst.Controls.Add(txtStokArama);

            dgvFirmaStok = Tema.Tablo();
            dgvFirmaStok.DataSource = aracTablosu;

            DurumEtiketi = Tema.DurumCubugu();

            pnlSag.Controls.Add(dgvFirmaStok);
            pnlSag.Controls.Add(pnlTabloUst);
            pnlSag.Controls.Add(DurumEtiketi);

            Controls.Add(pnlSag);
            Controls.Add(pnlSol);
            Controls.Add(pnlUstBar);
        }

        // GET /api/vehicles: firma hesabına yalnızca kendi araçları döner
        private async Task AraclariYukle()
        {
            araclar = await ApiIstemcisi.AraclariGetir();
            Guid? seciliId = TabloSecimi.SeciliId(dgvFirmaStok);

            aracTablosu.Rows.Clear();
            foreach (Arac a in araclar)
            {
                string marka = string.Join(" ", new[] { a.Brand, a.Model }).Trim();
                aracTablosu.Rows.Add(
                    a.Id,
                    a.Plate,
                    Etiketler.AracTuru(a.Type),
                    string.IsNullOrEmpty(marka) ? "-" : marka,
                    a.Year?.ToString() ?? "-",
                    a.Passengers?.ToString() ?? "-",
                    Sehirler.Adi(a.Lat, a.Lon),
                    Etiketler.AracDurumu(a.Status));
            }

            int musait = araclar.Count(a => a.Status == "AVAILABLE");
            lblStokOzet.Text = $"({araclar.Count} araç · {musait} müsait)";

            ListeyiFiltrele();
            TabloSecimi.Sec(dgvFirmaStok, seciliId);
        }

        private void ListeyiFiltrele()
        {
            string aranan = txtStokArama.Text.Trim().Replace("'", "''").Replace("[", "[[]").Replace("%", "[%]").Replace("*", "[*]");
            aracTablosu.DefaultView.RowFilter = string.IsNullOrEmpty(aranan)
                ? ""
                : $"[Plaka] LIKE '%{aranan}%' OR [Marka / Model] LIKE '%{aranan}%' OR [Araç Türü] LIKE '%{aranan}%'";
        }

        private static bool SayiOku(TextBox txt, string alanAdi, int min, int max, out int? deger)
        {
            deger = null;
            string metin = txt.Text.Trim();
            if (metin.Length == 0) return true;

            if (int.TryParse(metin, out int sayi) && sayi >= min && sayi <= max)
            {
                deger = sayi;
                return true;
            }

            Tema.Uyari($"{alanAdi} {min} ile {max} arasında bir sayı olmalıdır (boş bırakılabilir).");
            txt.Focus();
            return false;
        }

        private static string? BosIseNull(TextBox txt) =>
            string.IsNullOrWhiteSpace(txt.Text) ? null : txt.Text.Trim();

        private void FirmaUygulamaPenceresi_Load(object? sender, EventArgs e) { }

        private async void btnAracKaydet_Click(object? sender, EventArgs e)
        {
            Guid? firmaId = ApiIstemcisi.AktifKullanici?.CompanyId;
            if (firmaId == null)
            {
                Tema.Uyari("Firma bilgisi bulunamadı. Lütfen çıkış yapıp tekrar giriş yapınız.");
                return;
            }

            string plaka = txtPlaka.Text.Trim();
            if (plaka.Length == 0)
            {
                Tema.Uyari("Lütfen aracın plakasını giriniz.");
                txtPlaka.Focus();
                return;
            }

            if (!SayiOku(txtYil, "Model yılı", 1900, 2100, out int? yil)) return;
            if (!SayiOku(txtKapasite, "Kapasite", 0, 1000, out int? kapasite)) return;

            var girdi = new AracGirdisi
            {
                CompanyId = firmaId.Value,
                Plate = plaka,
                Type = Etiketler.AracTurleri[cmbFirmaAracTuru.SelectedIndex].Kod,
                Brand = BosIseNull(txtMarka),
                Model = BosIseNull(txtModel),
                Year = yil,
                Passengers = kapasite,
                Lat = (double)nudEnlem.Value,
                Lon = (double)nudBoylam.Value,
                Status = Etiketler.AracDurumlariSecilebilir[cmbDurum.SelectedIndex].Kod
            };

            bool basarili = await IslemYap(btnAracKaydet, () => ApiIstemcisi.AracEkle(girdi));
            if (!basarili) return;

            Tema.Bilgi($"{plaka.ToUpperInvariant()} plakalı {Etiketler.AracTuru(girdi.Type).ToLower()} filoya eklendi.");
            txtPlaka.Clear();
            txtMarka.Clear();
            txtModel.Clear();
            txtYil.Clear();
            txtKapasite.Clear();
            await VerileriYenile();
        }

        private void btnFirmaRezervasyonAc_Click(object? sender, EventArgs e)
        {
            Gec(new FirmaRezervasyonPenceresi());
        }

        private void btnFirmaCikis_Click(object? sender, EventArgs e)
        {
            GirisEkraninaDon();
        }
    }
}
