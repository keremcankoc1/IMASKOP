﻿using System;
using System.Windows.Forms;

namespace afad
{
    // Firmaya AFAD'dan gelen sevk talepleri (rezervasyonlar).
    // Firma onaylar (PENDING -> CONFIRMED), görev bitince tamamlar (CONFIRMED -> COMPLETED) veya iptal eder.
    public partial class FirmaRezervasyonPenceresi : RezervasyonEkrani
    {
        private readonly Button btnGorevTamamla;
        private readonly Button btnIptal;

        public FirmaRezervasyonPenceresi()
        {
            InitializeComponent();

            btnFirmaGeriDon = Tema.Buton("Araç Paneline Dön", Tema.IkincilButon, 165, 36);
            btnFirmaGeriDon.Click += btnFirmaGeriDon_Click;

            // POST /api/reservations/{id}/confirm
            btnRezervasyonOnayla = Tema.Buton("Talebi Onayla ve Sevk Et", Tema.Basari, 278, 40);
            btnRezervasyonOnayla.Click += btnRezervasyonOnayla_Click;

            // POST /api/reservations/{id}/complete
            btnGorevTamamla = Tema.Buton("Görevi Tamamla", Tema.AnaVurgu, 278, 40);
            btnGorevTamamla.Click += BtnGorevTamamla_Click;

            // POST /api/reservations/{id}/cancel
            btnIptal = Tema.Buton("Rezervasyonu İptal Et", Tema.Tehlike, 278, 40);
            btnIptal.Click += BtnIptal_Click;

            string ad = ApiIstemcisi.AktifKullanici?.Name ?? "Firma";
            EkraniKur(
                "Firma - AFAD Sevk Talepleri",
                $"FİRMA | {ad}",
                new[] { btnFirmaGeriDon },
                "AFAD'dan Gelen Sevk Talepleri",
                new[] { btnRezervasyonOnayla, btnGorevTamamla, btnIptal },
                "Yeni talepler bu listeye otomatik düşer.",
                sevkKonumuGoster: false);
        }

        protected override void ButonlariGuncelle(Rezervasyon? secili)
        {
            string durum = secili?.Status ?? "";
            Tema.ButonDurumu(btnRezervasyonOnayla, durum == "PENDING");
            Tema.ButonDurumu(btnGorevTamamla, durum == "CONFIRMED");
            Tema.ButonDurumu(btnIptal, durum == "PENDING" || durum == "CONFIRMED");
        }

        private async void btnRezervasyonOnayla_Click(object? sender, EventArgs e)
        {
            await RezervasyonIslemiYap(
                btnRezervasyonOnayla,
                "Seçili aracın AFAD'a sevkini onaylıyor musunuz?",
                ApiIstemcisi.RezervasyonuOnayla,
                "AFAD araç sevk talebi onaylandı!");
        }

        private async void BtnGorevTamamla_Click(object? sender, EventArgs e)
        {
            await RezervasyonIslemiYap(
                btnGorevTamamla,
                "Sevk görevi tamamlandı olarak işaretlensin mi?",
                ApiIstemcisi.RezervasyonuTamamla,
                "Görev tamamlandı olarak işaretlendi.");
        }

        private async void BtnIptal_Click(object? sender, EventArgs e)
        {
            await RezervasyonIslemiYap(
                btnIptal,
                "Seçili rezervasyonu iptal etmek istediğinize emin misiniz?\n(AFAD talebi de iptal edilmiş olacaktır.)",
                ApiIstemcisi.RezervasyonuIptalEt,
                "Rezervasyon iptal edildi.");
        }

        private void FirmaRezervasyonPenceresi_Load(object? sender, EventArgs e) { }

        private void btnFirmaGeriDon_Click(object? sender, EventArgs e)
        {
            Gec(new FirmaUygulamaPenceresi());
        }
    }
}
