using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace afad
{
    // AFAD sevk paneli: araç talebi oluşturur, müsait araçları listeler ve seçilen aracı rezerve eder.
    // Akış (docs/API.md): POST /api/requests -> POST /api/requests/{id}/match -> POST /api/reservations
    public partial class AfadUygulamaPenceresi : UygulamaFormu
    {
        private readonly string aktifKullaniciAdi;

        private ComboBox cmbSehir = null!;
        private NumericUpDown nudEnlem = null!;
        private NumericUpDown nudBoylam = null!;
        private DateTimePicker dtpBaslangic = null!;
        private DateTimePicker dtpBitis = null!;
        private Label lblSeciliArac = null!;
        private Label lblSeciliAracDetay = null!;
        private Label lblAracSayaci = null!;
        private TextBox txtArama = null!;
        private CheckBox chkSadeceMusait = null!;

        private List<Arac> araclar = new();
        private readonly DataTable aracTablosu = new();

        public AfadUygulamaPenceresi() : this("")
        {
        }

        public AfadUygulamaPenceresi(string kullaniciAdi)
        {
            InitializeComponent();

            aktifKullaniciAdi = string.IsNullOrWhiteSpace(kullaniciAdi)
                ? ApiIstemcisi.AktifKullanici?.Name ?? "Yetkili Personel"
                : kullaniciAdi.Trim();

            TabloyuHazirla();
            SadeArayuzuOlustur();
            VeriYukleyiciAyarla(AraclariYukle, otomatikYenilemeSaniyesi: 30);
        }

        private void TabloyuHazirla()
        {
            aracTablosu.Columns.Add("Id", typeof(Guid));
            aracTablosu.Columns.Add("Plaka", typeof(string));
            aracTablosu.Columns.Add("Araç Türü", typeof(string));
            aracTablosu.Columns.Add("Marka / Model", typeof(string));
            aracTablosu.Columns.Add("Kapasite (kişi)", typeof(string));
            aracTablosu.Columns.Add("Konum", typeof(string));
            aracTablosu.Columns.Add("Uzaklık (km)", typeof(int));
            aracTablosu.Columns.Add("Durum", typeof(string));
        }

        private void SadeArayuzuOlustur()
        {
            Tema.FormuHazirla(this, "AFAD - Lojistik ve Sevk Sistemi");

            // =========================================================
            // 1. ÜST BAR
            // =========================================================
            Panel pnlUstBar = Tema.UstBarOlustur($"AFAD | {aktifKullaniciAdi}");

            btnAfadCikis = Tema.Buton("Çıkış Yap", Tema.Tehlike, 115, 36);
            btnAfadCikis.Click += btnAfadCikis_Click;

            btnAfadRezervasyonAc = Tema.Buton("Rezervasyonlar", Tema.IkincilButon, 145, 36);
            btnAfadRezervasyonAc.Click += btnAfadRezervasyonAc_Click;

            Tema.UstBarButonlariEkle(pnlUstBar, btnAfadCikis, btnAfadRezervasyonAc);

            // =========================================================
            // 2. SOL PANEL (TALEP BİLGİLERİ VE REZERVASYON)
            // =========================================================
            Panel pnlSol = Tema.SolPanelOlustur("Araç Talebi ve Rezervasyon");

            pnlSol.Controls.Add(Tema.AlanBasligi("Araç Türü", 20, 58));
            cmbAracTuru = Tema.SecimKutusu(20, 80, 278);
            foreach (var tur in Etiketler.AracTurleri) cmbAracTuru.Items.Add(tur.Ad);
            cmbAracTuru.SelectedIndex = 0;
            cmbAracTuru.SelectedIndexChanged += async (s, e) => await VerileriYenile();
            pnlSol.Controls.Add(cmbAracTuru);

            pnlSol.Controls.Add(Tema.AlanBasligi("Sevk Edilecek Konum (enlem / boylam)", 20, 122));
            cmbSehir = Tema.SecimKutusu(20, 144, 278);
            pnlSol.Controls.Add(cmbSehir);
            nudEnlem = Tema.SayiKutusu(20, 182, 133, -90, 90, 4);
            nudBoylam = Tema.SayiKutusu(165, 182, 133, -180, 180, 4);
            nudEnlem.ValueChanged += (s, e) => UzakliklariGuncelle();
            nudBoylam.ValueChanged += (s, e) => UzakliklariGuncelle();
            pnlSol.Controls.Add(nudEnlem);
            pnlSol.Controls.Add(nudBoylam);
            Sehirler.SecimKutusunuBagla(cmbSehir, nudEnlem, nudBoylam);

            DateTime varsayilanBaslangic = DateTime.Now.Date.AddHours(DateTime.Now.Hour + 1);

            pnlSol.Controls.Add(Tema.AlanBasligi("Görev Başlangıcı", 20, 222));
            dtpBaslangic = Tema.TarihSecici(20, 244, 278);
            dtpBaslangic.Value = varsayilanBaslangic;
            pnlSol.Controls.Add(dtpBaslangic);

            pnlSol.Controls.Add(Tema.AlanBasligi("Görev Bitişi", 20, 284));
            dtpBitis = Tema.TarihSecici(20, 306, 278);
            dtpBitis.Value = varsayilanBaslangic.AddHours(8);
            pnlSol.Controls.Add(dtpBitis);

            Button btnListele = Tema.Buton("Bu Tarihlerde Müsait Araçları Listele", Tema.IkincilButon, 278, 38);
            btnListele.Location = new Point(20, 350);
            btnListele.Click += async (s, e) =>
            {
                chkSadeceMusait.Checked = true;
                await VerileriYenile();
            };
            pnlSol.Controls.Add(btnListele);

            Panel pnlSeciliArac = new Panel
            {
                Location = new Point(20, 402),
                Size = new Size(278, 64),
                BackColor = Tema.ArkaPlan
            };
            pnlSeciliArac.Controls.Add(Tema.DetayBasligi("Seçili Araç:", 6));
            lblSeciliArac = Tema.DetayDegeri("Listeden araç seçiniz", 22);
            lblSeciliAracDetay = new Label
            {
                Text = "",
                ForeColor = Tema.MetinSoluk,
                Font = new Font("Segoe UI", 8.5F),
                Location = new Point(12, 42),
                Size = new Size(254, 18),
                AutoEllipsis = true
            };
            pnlSeciliArac.Controls.Add(lblSeciliArac);
            pnlSeciliArac.Controls.Add(lblSeciliAracDetay);
            pnlSol.Controls.Add(pnlSeciliArac);

            btnSevkEmri = Tema.Buton("Talebi Oluştur ve Aracı Rezerve Et", Tema.AnaVurgu, 278, 42);
            btnSevkEmri.Location = new Point(20, 478);
            btnSevkEmri.Click += button1_Click;
            pnlSol.Controls.Add(btnSevkEmri);

            // =========================================================
            // 3. SAĞ PANEL (ARAÇ LİSTESİ)
            // =========================================================
            Panel pnlSag = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(24, 18, 24, 8),
                BackColor = Tema.ArkaPlan
            };

            Panel pnlTabloUst = Tema.TabloUstBar("Firma ve Araç Envanteri", out lblAracSayaci);

            txtArama = new TextBox
            {
                Width = 160,
                Font = new Font("Segoe UI", 9.5F),
                BackColor = Tema.Panel,
                ForeColor = Tema.MetinAna,
                BorderStyle = BorderStyle.FixedSingle,
                PlaceholderText = "Plaka / Marka ara...",
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(pnlTabloUst.Width - 160, 8)
            };
            txtArama.TextChanged += (s, e) => AramayiUygula();

            chkSadeceMusait = new CheckBox
            {
                Text = "Yalnızca müsait olanlar",
                Checked = true,
                AutoSize = true,
                ForeColor = Tema.MetinSoluk,
                Font = new Font("Segoe UI", 9F),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(pnlTabloUst.Width - 335, 11)
            };
            chkSadeceMusait.CheckedChanged += async (s, e) => await VerileriYenile();

            pnlTabloUst.Controls.Add(txtArama);
            pnlTabloUst.Controls.Add(chkSadeceMusait);

            dgwFirmaStoklari = Tema.Tablo();
            dgwFirmaStoklari.DataSource = aracTablosu;
            dgwFirmaStoklari.SelectionChanged += DgwFirmaStoklari_SelectionChanged;

            DurumEtiketi = Tema.DurumCubugu();

            pnlSag.Controls.Add(dgwFirmaStoklari);
            pnlSag.Controls.Add(pnlTabloUst);
            pnlSag.Controls.Add(DurumEtiketi);

            Controls.Add(pnlSag);
            Controls.Add(pnlSol);
            Controls.Add(pnlUstBar);

            DgwFirmaStoklari_SelectionChanged(null, EventArgs.Empty);
        }

        private string SeciliTurKodu() => Etiketler.AracTurleri[Math.Max(cmbAracTuru.SelectedIndex, 0)].Kod;

        private DateTimeOffset Baslangic => new DateTimeOffset(dtpBaslangic.Value);
        private DateTimeOffset Bitis => new DateTimeOffset(dtpBitis.Value);

        // GET /api/vehicles (müsaitlik için tür + tarih aralığı filtresiyle)
        private async Task AraclariYukle()
        {
            bool sadeceMusait = chkSadeceMusait.Checked;
            if (sadeceMusait && Bitis <= Baslangic)
                throw new InvalidOperationException("Görev bitişi, başlangıçtan sonra olmalıdır.");

            araclar = sadeceMusait
                ? await ApiIstemcisi.AraclariGetir(SeciliTurKodu(), Baslangic, Bitis)
                : await ApiIstemcisi.AraclariGetir();

            Guid? seciliId = TabloSecimi.SeciliId(dgwFirmaStoklari);

            aracTablosu.Rows.Clear();
            foreach (Arac a in araclar)
            {
                string marka = string.Join(" ", new[] { a.Brand, a.Model }).Trim();
                aracTablosu.Rows.Add(
                    a.Id,
                    a.Plate,
                    Etiketler.AracTuru(a.Type),
                    string.IsNullOrEmpty(marka) ? "-" : marka + (a.Year.HasValue ? $" ({a.Year})" : ""),
                    a.Passengers?.ToString() ?? "-",
                    Sehirler.Adi(a.Lat, a.Lon),
                    DBNull.Value,
                    Etiketler.AracDurumu(a.Status));
            }

            UzakliklariGuncelle();
            AramayiUygula();

            lblAracSayaci.Text = sadeceMusait
                ? $"({araclar.Count} müsait {Etiketler.AracTuru(SeciliTurKodu()).ToLower()})"
                : $"({araclar.Count} araç)";

            TabloSecimi.Sec(dgwFirmaStoklari, seciliId);
            DgwFirmaStoklari_SelectionChanged(null, EventArgs.Empty);
        }

        // Sevk konumuna olan kuş uçuşu uzaklığı hesaplar, en yakın araç en üstte görünür
        private void UzakliklariGuncelle()
        {
            if (nudEnlem == null || nudBoylam == null) return;

            double enlem = (double)nudEnlem.Value;
            double boylam = (double)nudBoylam.Value;
            Guid? seciliId = TabloSecimi.SeciliId(dgwFirmaStoklari);

            foreach (DataRow satir in aracTablosu.Rows)
            {
                Arac? a = araclar.FirstOrDefault(x => x.Id == (Guid)satir["Id"]);
                satir["Uzaklık (km)"] = a?.Lat != null && a.Lon != null
                    ? (int)Math.Round(Sehirler.MesafeKm(enlem, boylam, a.Lat.Value, a.Lon.Value))
                    : DBNull.Value;
            }

            aracTablosu.DefaultView.Sort = "[Uzaklık (km)] ASC";
            TabloSecimi.Sec(dgwFirmaStoklari, seciliId);
        }

        private void AramayiUygula()
        {
            string aranan = txtArama.Text.Trim().Replace("'", "''").Replace("[", "[[]").Replace("%", "[%]").Replace("*", "[*]");
            aracTablosu.DefaultView.RowFilter = string.IsNullOrEmpty(aranan)
                ? ""
                : $"[Plaka] LIKE '%{aranan}%' OR [Marka / Model] LIKE '%{aranan}%' OR [Konum] LIKE '%{aranan}%'";
        }

        private Arac? SeciliArac()
        {
            Guid? id = TabloSecimi.SeciliId(dgwFirmaStoklari);
            return id == null ? null : araclar.FirstOrDefault(a => a.Id == id);
        }

        private void DgwFirmaStoklari_SelectionChanged(object? sender, EventArgs e)
        {
            Arac? arac = SeciliArac();
            if (arac != null)
            {
                lblSeciliArac.Text = Etiketler.AracAdi(arac);
                lblSeciliAracDetay.Text = $"{Etiketler.AracTuru(arac.Type)} · {Sehirler.Adi(arac.Lat, arac.Lon)} · {Etiketler.AracDurumu(arac.Status)}";
            }
            else
            {
                lblSeciliArac.Text = "Listeden araç seçiniz";
                lblSeciliAracDetay.Text = "";
            }

            Tema.ButonDurumu(btnSevkEmri, arac != null);
        }

        // Talebi oluşturur, seçilen araçla eşleştirir ve rezervasyonu açar
        private async void button1_Click(object? sender, EventArgs e)
        {
            Arac? arac = SeciliArac();
            if (arac == null)
            {
                Tema.Uyari("Lütfen listeden rezerve edilecek aracı seçiniz.");
                return;
            }
            if (Bitis <= Baslangic)
            {
                Tema.Uyari("Görev bitişi, başlangıçtan sonra olmalıdır.");
                return;
            }

            string konum = Sehirler.Adi((double)nudEnlem.Value, (double)nudBoylam.Value);
            DialogResult onay = MessageBox.Show(
                $"{Etiketler.AracAdi(arac)} ({Etiketler.AracTuru(arac.Type)}) aracı\n" +
                $"{konum} konumuna, {Etiketler.Zaman(Baslangic)} - {Etiketler.Zaman(Bitis)} arası için rezerve edilsin mi?\n\n" +
                "Rezervasyon, araç sahibi firmanın onayına gönderilecektir.",
                "Rezervasyon Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (onay != DialogResult.Yes) return;

            bool basarili = await IslemYap(btnSevkEmri, async () =>
            {
                Talep talep = await ApiIstemcisi.TalepOlustur(new TalepGirdisi
                {
                    PickUpLat = (double)nudEnlem.Value,
                    PickUpLon = (double)nudBoylam.Value,
                    VehicleType = arac.Type,
                    StartAt = Baslangic,
                    EndAt = Bitis
                });

                await ApiIstemcisi.TalebiEslestir(talep.Id, arac.Id);
                await ApiIstemcisi.RezervasyonOlustur(talep.Id, arac.Id);
            });

            if (basarili)
                Tema.Bilgi($"{arac.Plate} plakalı araç rezerve edildi. Firma onayladığında Rezervasyonlar ekranında durumu güncellenecektir.");

            await VerileriYenile();
        }

        private void Form1_Load(object? sender, EventArgs e) { }
        private void label1_Click(object? sender, EventArgs e) { }
        private void label4_Click(object? sender, EventArgs e) { }
        private void dgwFirmaStoklari_CellContentClick(object? sender, DataGridViewCellEventArgs e) { }

        private void btnAfadRezervasyonAc_Click(object? sender, EventArgs e)
        {
            Gec(new AfadRezervasyonPenceresi(aktifKullaniciAdi));
        }

        private void btnAfadCikis_Click(object? sender, EventArgs e)
        {
            GirisEkraninaDon();
        }
    }
}
