using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace afad
{
    // AFAD ve firma rezervasyon ekranlarının ortak iskeleti:
    // GET /api/reservations listesi, durum filtresi, detay kartı ve otomatik yenileme.
    // Hangi işlem butonlarının görüneceğini türeyen pencere belirler.
    public class RezervasyonEkrani : UygulamaFormu
    {
        protected DataGridView Liste = null!;
        protected List<Rezervasyon> Rezervasyonlar = new();
        protected Dictionary<Guid, Arac> Araclar = new();
        protected Dictionary<Guid, Talep> Talepler = new();

        private readonly DataTable tablo = new();
        private Label lblSayac = null!;
        private TextBox txtArama = null!;
        private ComboBox cmbDurumFiltre = null!;
        private Label lblNo = null!;
        private Label lblArac = null!;
        private Label lblKonum = null!;
        private Label lblZaman = null!;
        private Label lblDurum = null!;
        private bool konumGosterilsin;

        // Sevk konumu yalnızca talebi görebilen AFAD hesabında bilinir (firma talepleri okuyamaz)
        protected void EkraniKur(string pencereBasligi, string ustBarBasligi, Button[] ustButonlar,
                                 string tabloBasligi, Button[] islemButonlari, string bilgiNotu, bool sevkKonumuGoster)
        {
            konumGosterilsin = sevkKonumuGoster;
            TabloyuHazirla();
            Tema.FormuHazirla(this, pencereBasligi);

            // 1. ÜST BAR
            Panel pnlUstBar = Tema.UstBarOlustur(ustBarBasligi);
            Tema.UstBarButonlariEkle(pnlUstBar, ustButonlar);

            // 2. SOL PANEL (DETAY KARTI VE İŞLEMLER)
            Panel pnlSol = Tema.SolPanelOlustur("Rezervasyon İşlemleri");

            Panel pnlDetay = new Panel
            {
                Location = new Point(20, 54),
                Size = new Size(278, 216),
                BackColor = Tema.ArkaPlan
            };
            pnlDetay.Controls.Add(Tema.DetayBasligi("Rezervasyon No:", 12));
            lblNo = Tema.DetayDegeri("Seçim yapılmadı", 30);
            pnlDetay.Controls.Add(Tema.DetayBasligi("Araç:", 56));
            lblArac = Tema.DetayDegeri("-", 74);
            pnlDetay.Controls.Add(Tema.DetayBasligi("Sevk Konumu:", 100));
            lblKonum = Tema.DetayDegeri("-", 118);
            pnlDetay.Controls.Add(Tema.DetayBasligi("Görev Zamanı:", 144));
            lblZaman = Tema.DetayDegeri("-", 162);
            pnlDetay.Controls.Add(Tema.DetayBasligi("Durum:", 190));
            lblDurum = new Label
            {
                Text = "-",
                ForeColor = Tema.MetinAna,
                Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold),
                Location = new Point(60, 189),
                AutoSize = true
            };
            pnlDetay.Controls.AddRange(new Control[] { lblNo, lblArac, lblKonum, lblZaman, lblDurum });
            pnlSol.Controls.Add(pnlDetay);

            pnlSol.Controls.Add(Tema.AlanBasligi("Seçili Kayıt Üzerinde İşlem Yap:", 20, 286));
            int y = 312;
            foreach (Button btn in islemButonlari)
            {
                btn.Location = new Point(20, y);
                pnlSol.Controls.Add(btn);
                y += 50;
            }

            pnlSol.Controls.Add(new Label
            {
                Text = bilgiNotu,
                ForeColor = Tema.MetinSoluk,
                Font = new Font("Segoe UI", 8.5F),
                Location = new Point(20, y + 4),
                Size = new Size(278, 60)
            });

            // 3. SAĞ PANEL (LİSTE)
            Panel pnlSag = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(24, 18, 24, 8),
                BackColor = Tema.ArkaPlan
            };

            Panel pnlTabloUst = Tema.TabloUstBar(tabloBasligi, out lblSayac);

            cmbDurumFiltre = new ComboBox
            {
                Width = 160,
                Font = new Font("Segoe UI", 9F),
                BackColor = Tema.Panel,
                ForeColor = Tema.MetinAna,
                FlatStyle = FlatStyle.Flat,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(pnlTabloUst.Width - 160, 8)
            };
            cmbDurumFiltre.Items.AddRange(new object[]
            {
                "Tüm Durumlar", Etiketler.Beklemede, Etiketler.Onaylandi, Etiketler.Tamamlandi, Etiketler.IptalEdildi
            });
            cmbDurumFiltre.SelectedIndex = 0;
            cmbDurumFiltre.SelectedIndexChanged += (s, e) => FiltreyiUygula();

            txtArama = new TextBox
            {
                Width = 160,
                Font = new Font("Segoe UI", 9.5F),
                BackColor = Tema.Panel,
                ForeColor = Tema.MetinAna,
                BorderStyle = BorderStyle.FixedSingle,
                PlaceholderText = "Plaka / No ara...",
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(pnlTabloUst.Width - 330, 8)
            };
            txtArama.TextChanged += (s, e) => FiltreyiUygula();

            pnlTabloUst.Controls.Add(txtArama);
            pnlTabloUst.Controls.Add(cmbDurumFiltre);

            Liste = Tema.Tablo();
            Liste.DataSource = tablo;
            Liste.DataBindingComplete += (s, e) =>
            {
                if (Liste.Columns.Contains("DurumKodu")) Liste.Columns["DurumKodu"]!.Visible = false;
            };
            Liste.CellFormatting += Liste_CellFormatting;
            Liste.SelectionChanged += (s, e) => SecimiGoster();

            DurumEtiketi = Tema.DurumCubugu();

            pnlSag.Controls.Add(Liste);
            pnlSag.Controls.Add(pnlTabloUst);
            pnlSag.Controls.Add(DurumEtiketi);

            Controls.Add(pnlSag);
            Controls.Add(pnlSol);
            Controls.Add(pnlUstBar);

            SecimiGoster();
            VeriYukleyiciAyarla(Yukle, otomatikYenilemeSaniyesi: 10);
        }

        private void TabloyuHazirla()
        {
            tablo.Columns.Add("Id", typeof(Guid));
            tablo.Columns.Add("DurumKodu", typeof(string));
            tablo.Columns.Add("Rezervasyon No", typeof(string));
            tablo.Columns.Add("Plaka", typeof(string));
            tablo.Columns.Add("Araç Türü", typeof(string));
            if (konumGosterilsin) tablo.Columns.Add("Sevk Konumu", typeof(string));
            tablo.Columns.Add("Başlangıç", typeof(string));
            tablo.Columns.Add("Bitiş", typeof(string));
            tablo.Columns.Add("Durum", typeof(string));
        }

        private async Task Yukle()
        {
            var rezervasyonGorevi = ApiIstemcisi.RezervasyonlariGetir();
            var aracGorevi = ApiIstemcisi.AraclariGetir();
            var talepGorevi = konumGosterilsin ? ApiIstemcisi.TalepleriGetir() : Task.FromResult(new List<Talep>());
            await Task.WhenAll(rezervasyonGorevi, aracGorevi, talepGorevi);

            Rezervasyonlar = rezervasyonGorevi.Result;
            Araclar = aracGorevi.Result.ToDictionary(a => a.Id);
            Talepler = talepGorevi.Result.ToDictionary(t => t.Id);

            Guid? seciliId = TabloSecimi.SeciliId(Liste);

            tablo.Rows.Clear();
            foreach (Rezervasyon r in Rezervasyonlar)
            {
                Araclar.TryGetValue(r.VehicleId, out Arac? arac);
                DataRow satir = tablo.NewRow();
                satir["Id"] = r.Id;
                satir["DurumKodu"] = r.Status;
                satir["Rezervasyon No"] = Etiketler.KisaNo(r.Id);
                satir["Plaka"] = arac?.Plate ?? "-";
                satir["Araç Türü"] = arac != null ? Etiketler.AracTuru(arac.Type) : "-";
                if (konumGosterilsin)
                    satir["Sevk Konumu"] = Talepler.TryGetValue(r.RequestId, out Talep? t) ? Sehirler.Adi(t.PickUpLat, t.PickUpLon) : "-";
                satir["Başlangıç"] = Etiketler.Zaman(r.StartAt);
                satir["Bitiş"] = Etiketler.Zaman(r.EndAt);
                satir["Durum"] = Etiketler.RezervasyonDurumu(r.Status);
                tablo.Rows.Add(satir);
            }

            int bekleyen = Rezervasyonlar.Count(r => r.Status == "PENDING");
            int onayli = Rezervasyonlar.Count(r => r.Status == "CONFIRMED");
            lblSayac.Text = $"({Rezervasyonlar.Count} kayıt · {bekleyen} onay bekliyor · {onayli} onaylı)";

            FiltreyiUygula();
            TabloSecimi.Sec(Liste, seciliId);
            SecimiGoster();
        }

        private void FiltreyiUygula()
        {
            var kosullar = new List<string>();

            string aranan = txtArama.Text.Trim().Replace("'", "''").Replace("[", "[[]").Replace("%", "[%]").Replace("*", "[*]");
            if (!string.IsNullOrEmpty(aranan))
                kosullar.Add($"([Plaka] LIKE '%{aranan}%' OR [Rezervasyon No] LIKE '%{aranan}%'" +
                             (konumGosterilsin ? $" OR [Sevk Konumu] LIKE '%{aranan}%'" : "") + ")");

            if (cmbDurumFiltre.SelectedIndex > 0)
                kosullar.Add($"[Durum] = '{cmbDurumFiltre.SelectedItem}'");

            Guid? seciliId = TabloSecimi.SeciliId(Liste);
            tablo.DefaultView.RowFilter = string.Join(" AND ", kosullar);
            TabloSecimi.Sec(Liste, seciliId);
        }

        private void Liste_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.CellStyle == null || Liste.Columns[e.ColumnIndex].Name != "Durum") return;

            string kod = Liste.Rows[e.RowIndex].Cells["DurumKodu"].Value?.ToString() ?? "";
            Color renk = Etiketler.RezervasyonRengi(kod);
            e.CellStyle.ForeColor = renk;
            e.CellStyle.SelectionForeColor = renk;
            e.CellStyle.Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold);
        }

        protected Rezervasyon? SeciliRezervasyon()
        {
            Guid? id = TabloSecimi.SeciliId(Liste);
            return id == null ? null : Rezervasyonlar.FirstOrDefault(r => r.Id == id);
        }

        protected void SecimiGoster()
        {
            Rezervasyon? r = SeciliRezervasyon();
            if (r != null)
            {
                lblNo.Text = Etiketler.KisaNo(r.Id);
                lblArac.Text = Araclar.TryGetValue(r.VehicleId, out Arac? a)
                    ? $"{Etiketler.AracTuru(a.Type)} · {Etiketler.AracAdi(a)}"
                    : "-";
                lblKonum.Text = Talepler.TryGetValue(r.RequestId, out Talep? t)
                    ? Sehirler.Adi(t.PickUpLat, t.PickUpLon) + $"  ({t.PickUpLat:0.0000}, {t.PickUpLon:0.0000})"
                    : (konumGosterilsin ? "-" : "API firmaya konum göndermiyor");
                lblZaman.Text = $"{Etiketler.Zaman(r.StartAt)} - {r.EndAt.ToLocalTime():HH:mm dd.MM}";
                lblDurum.Text = Etiketler.RezervasyonDurumu(r.Status);
                lblDurum.ForeColor = Etiketler.RezervasyonRengi(r.Status);
            }
            else
            {
                lblNo.Text = "Seçim yapılmadı";
                lblArac.Text = "-";
                lblKonum.Text = "-";
                lblZaman.Text = "-";
                lblDurum.Text = "-";
                lblDurum.ForeColor = Tema.MetinAna;
            }

            ButonlariGuncelle(r);
        }

        // Türeyen pencere, seçili rezervasyonun durumuna göre butonlarını açıp kapatır
        protected virtual void ButonlariGuncelle(Rezervasyon? secili) { }

        // Onay sorusunu sorar, API işlemini yapar, listeyi yeniler
        protected async Task RezervasyonIslemiYap(Button buton, string soru, Func<Guid, Task<Rezervasyon>> islem, string basariMesaji)
        {
            Rezervasyon? r = SeciliRezervasyon();
            if (r == null)
            {
                Tema.Uyari("Lütfen listeden işlem yapılacak rezervasyonu seçiniz.");
                return;
            }

            if (MessageBox.Show(soru, "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            bool basarili = await IslemYap(buton, () => islem(r.Id));
            if (basarili) Tema.Bilgi(basariMesaji);

            await VerileriYenile();
            SecimiGoster();
        }
    }
}
