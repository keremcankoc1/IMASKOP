using System;
using System.Drawing;
using System.Windows.Forms;

namespace afad
{
    // Küçük, tek sütunlu giriş pencerelerinin ortak iskeleti
    public class KucukPencere : Form
    {
        protected readonly Panel Govde;
        protected int SiradakiY = 70;
        protected readonly Button BtnKaydet;
        private readonly Button btnVazgec;

        public KucukPencere(string baslik, string aciklama, string kaydetMetni)
        {
            Text = baslik;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Panel;
            Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);
            ClientSize = new Size(380, 200);

            Govde = new Panel { Dock = DockStyle.Fill, BackColor = Tema.Panel };
            Controls.Add(Govde);

            Govde.Controls.Add(new Label
            {
                Text = baslik,
                ForeColor = Tema.MetinAna,
                Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(24, 18)
            });
            Govde.Controls.Add(new Label
            {
                Text = aciklama,
                ForeColor = Tema.MetinSoluk,
                Font = new Font("Segoe UI", 8.5F),
                Location = new Point(24, 44),
                Size = new Size(332, 20),
                AutoEllipsis = true
            });

            BtnKaydet = Tema.Buton(kaydetMetni, Tema.AnaVurgu, 200, 38);
            btnVazgec = Tema.Buton("Vazgeç", Tema.IkincilButon, 122, 38);
            btnVazgec.DialogResult = DialogResult.Cancel;
            CancelButton = btnVazgec;
            AcceptButton = BtnKaydet;
        }

        protected TextBox MetinAlani(string baslik, string ipucu = "", bool parola = false)
        {
            Govde.Controls.Add(Tema.AlanBasligi(baslik, 24, SiradakiY));
            TextBox txt = Tema.MetinKutusu(24, SiradakiY + 22, 332, ipucu);
            txt.UseSystemPasswordChar = parola;
            Govde.Controls.Add(txt);
            SiradakiY += 62;
            return txt;
        }

        // Alanlar eklendikten sonra butonları en alta yerleştirir ve pencere boyunu ayarlar
        protected void Tamamla()
        {
            SiradakiY += 8;
            BtnKaydet.Location = new Point(24, SiradakiY);
            btnVazgec.Location = new Point(234, SiradakiY);
            Govde.Controls.Add(BtnKaydet);
            Govde.Controls.Add(btnVazgec);
            ClientSize = new Size(380, SiradakiY + 62);
        }

        protected void Kilitle(bool kilitli)
        {
            Tema.ButonDurumu(BtnKaydet, !kilitli);
            UseWaitCursor = kilitli;
        }
    }

    // POST /api/auth/register: lojistik firması için hesap açar
    public sealed class FirmaKayitPenceresi : KucukPencere
    {
        private readonly TextBox txtAd;
        private readonly TextBox txtEmail;
        private readonly TextBox txtParola;
        private readonly TextBox txtParolaTekrar;

        public string Email => txtEmail.Text.Trim();
        public string Parola => txtParola.Text;

        public FirmaKayitPenceresi()
            : base("Firma Hesabı Oluştur", "Lojistik firması yetkilisi için giriş hesabı açılır.", "Hesabı Oluştur")
        {
            txtAd = MetinAlani("Yetkili Adı Soyadı");
            txtEmail = MetinAlani("E-posta", "firma@ornek.com");
            txtParola = MetinAlani("Parola (en az 12 karakter)", "", parola: true);
            txtParolaTekrar = MetinAlani("Parola (tekrar)", "", parola: true);
            Tamamla();

            BtnKaydet.Click += BtnKaydet_Click;
        }

        private async void BtnKaydet_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAd.Text) || string.IsNullOrWhiteSpace(Email))
            {
                Tema.Uyari("Ad soyad ve e-posta zorunludur.");
                return;
            }
            if (System.Text.Encoding.UTF8.GetByteCount(Parola) < 12)
            {
                Tema.Uyari("Parola en az 12 karakter olmalıdır.");
                return;
            }
            if (Parola != txtParolaTekrar.Text)
            {
                Tema.Uyari("Parolalar birbiriyle aynı değil.");
                return;
            }

            Kilitle(true);
            try
            {
                await ApiIstemcisi.FirmaHesabiAc(txtAd.Text.Trim(), Email, Parola);
                Tema.Bilgi("Hesabınız oluşturuldu. Şimdi giriş yapılıp firma bilgileriniz istenecek.");
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                Tema.Hata(ex);
            }
            finally
            {
                Kilitle(false);
            }
        }
    }

    // POST /api/companies: firma hesabının ilk girişinde firma bilgilerini kaydeder
    public sealed class FirmaBilgiPenceresi : KucukPencere
    {
        private readonly TextBox txtFirmaAdi;
        private readonly TextBox txtVergiNo;
        private readonly TextBox txtTelefon;
        private readonly TextBox txtAdres;
        private readonly ComboBox cmbSehir;
        private readonly NumericUpDown nudEnlem;
        private readonly NumericUpDown nudBoylam;

        public FirmaBilgiPenceresi()
            : base("Firma Bilgileri", "Araç ekleyebilmek için firmanızı bir kez kaydetmeniz gerekiyor.", "Firmayı Kaydet")
        {
            txtFirmaAdi = MetinAlani("Firma Adı");
            txtVergiNo = MetinAlani("Vergi Numarası");
            txtTelefon = MetinAlani("Telefon (isteğe bağlı)");
            txtAdres = MetinAlani("Adres (isteğe bağlı)");

            Govde.Controls.Add(Tema.AlanBasligi("Firma Konumu", 24, SiradakiY));
            cmbSehir = Tema.SecimKutusu(24, SiradakiY + 22, 332);
            Govde.Controls.Add(cmbSehir);
            nudEnlem = Tema.SayiKutusu(24, SiradakiY + 60, 160, -90, 90, 4);
            nudBoylam = Tema.SayiKutusu(196, SiradakiY + 60, 160, -180, 180, 4);
            Govde.Controls.Add(nudEnlem);
            Govde.Controls.Add(nudBoylam);
            Sehirler.SecimKutusunuBagla(cmbSehir, nudEnlem, nudBoylam);
            SiradakiY += 100;
            Tamamla();

            BtnKaydet.Click += BtnKaydet_Click;
        }

        private static string? BosIseNull(TextBox txt) =>
            string.IsNullOrWhiteSpace(txt.Text) ? null : txt.Text.Trim();

        private async void BtnKaydet_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirmaAdi.Text) || string.IsNullOrWhiteSpace(txtVergiNo.Text))
            {
                Tema.Uyari("Firma adı ve vergi numarası zorunludur.");
                return;
            }

            Kilitle(true);
            try
            {
                await ApiIstemcisi.FirmaOlustur(new FirmaGirdisi
                {
                    Name = txtFirmaAdi.Text.Trim(),
                    TaxNumber = txtVergiNo.Text.Trim(),
                    Phone = BosIseNull(txtTelefon),
                    Address = BosIseNull(txtAdres),
                    Lat = (double)nudEnlem.Value,
                    Lon = (double)nudBoylam.Value
                });

                // Firma açılınca kullanıcıya company_id yazılır; güncel hali al
                await ApiIstemcisi.BilgilerimiYenile();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                Tema.Hata(ex);
            }
            finally
            {
                Kilitle(false);
            }
        }
    }
}
