using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace afad
{
    // Giriş sonrası açılan bütün pencerelerin ortak tabanı:
    // pencereler arası geçiş, sunucudan veri yenileme (otomatik dahil) ve hata/oturum yönetimi.
    public class UygulamaFormu : Form
    {
        protected Label? DurumEtiketi;

        private Func<Task>? veriYukleyici;
        private System.Windows.Forms.Timer? zamanlayici;
        private int otomatikSaniye;
        private bool yukleniyor;
        private bool gecisYapiliyor;
        private static bool uygulamaKapaniyor;

        // Başka bir pencereye geçer ve bu pencereyi kapatır
        protected void Gec(Form yeni)
        {
            gecisYapiliyor = true;
            yeni.Show();
            Close();
        }

        protected void GirisEkraninaDon()
        {
            ApiIstemcisi.OturumuKapat();
            UygulamaLoginPenceresi giris = Application.OpenForms.OfType<UygulamaLoginPenceresi>().FirstOrDefault()
                                           ?? new UygulamaLoginPenceresi();
            giris.EkraniSifirla();
            Gec(giris);
        }

        // Pencere kullanıcı tarafından (X ile) kapatılırsa uygulama tamamen kapanır
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            zamanlayici?.Stop();
            zamanlayici?.Dispose();
            base.OnFormClosed(e);
            if (!gecisYapiliyor && !uygulamaKapaniyor)
            {
                uygulamaKapaniyor = true;
                Application.Exit();
            }
        }

        // Pencere açılınca ve istenirse belirli aralıklarla çalışacak veri yükleme işlemini kaydeder
        protected void VeriYukleyiciAyarla(Func<Task> yukleyici, int otomatikYenilemeSaniyesi = 0)
        {
            veriYukleyici = yukleyici;
            otomatikSaniye = otomatikYenilemeSaniyesi;

            if (otomatikSaniye > 0)
            {
                zamanlayici = new System.Windows.Forms.Timer { Interval = otomatikSaniye * 1000 };
                zamanlayici.Tick += async (s, e) => await VerileriYenile(sessiz: true);
            }

            Shown += async (s, e) =>
            {
                await VerileriYenile();
                zamanlayici?.Start();
            };
        }

        protected async Task VerileriYenile(bool sessiz = false)
        {
            if (veriYukleyici == null || yukleniyor || IsDisposed) return;

            yukleniyor = true;
            try
            {
                DurumYaz("Sunucudan güncel veriler alınıyor...");
                await veriYukleyici();
                DurumYaz($"Son güncelleme: {DateTime.Now:HH:mm:ss}" +
                         (otomatikSaniye > 0 ? $"  ·  Liste {otomatikSaniye} saniyede bir otomatik yenilenir" : ""));
            }
            catch (Exception ex)
            {
                if (IsDisposed) return;
                DurumYaz("Güncellenemedi: " + ex.Message);
                if (!OturumDustuMu(ex) && !sessiz) Tema.Hata(ex);
            }
            finally
            {
                yukleniyor = false;
            }
        }

        // Bir butonun işlemini çalıştırır: işlem süresince butonu kilitler, hatayı gösterir
        protected async Task<bool> IslemYap(Button? buton, Func<Task> islem)
        {
            bool eskiDurum = buton?.Enabled ?? true;
            if (buton != null) Tema.ButonDurumu(buton, false);
            UseWaitCursor = true;
            try
            {
                await islem();
                return true;
            }
            catch (Exception ex)
            {
                if (!OturumDustuMu(ex)) Tema.Hata(ex);
                return false;
            }
            finally
            {
                UseWaitCursor = false;
                if (buton != null && !buton.IsDisposed) Tema.ButonDurumu(buton, eskiDurum);
            }
        }

        private bool OturumDustuMu(Exception ex)
        {
            if (ex is not ApiHatasi { HttpDurumu: 401 }) return false;

            zamanlayici?.Stop();
            Tema.Uyari(ex.Message);
            GirisEkraninaDon();
            return true;
        }

        protected void DurumYaz(string metin)
        {
            if (DurumEtiketi != null && !DurumEtiketi.IsDisposed) DurumEtiketi.Text = metin;
        }
    }
}
