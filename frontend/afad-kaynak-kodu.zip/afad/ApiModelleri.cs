using System;

namespace afad
{
    // IMASKOP API'sinin döndürdüğü / beklediği JSON gövdeleri (docs/API.md).
    // Alan adları JSON'da snake_case'e çevrilir: CompanyId -> company_id, PickUpLat -> pick_up_lat.

    public sealed class Kullanici
    {
        public Guid Id { get; set; }
        public string Email { get; set; } = "";
        public string Name { get; set; } = "";
        public string Role { get; set; } = "";          // ADMIN, COMPANY, CUSTOMER
        public Guid? CompanyId { get; set; }
    }

    public sealed class GirisYaniti
    {
        public string AccessToken { get; set; } = "";
        public DateTimeOffset ExpiresAt { get; set; }
        public Kullanici User { get; set; } = new();
    }

    public sealed class Firma
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = "";
        public string TaxNumber { get; set; } = "";
        public string? Phone { get; set; }
        public string? Address { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
    }

    public sealed class Arac
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public string Plate { get; set; } = "";
        public string Type { get; set; } = "";           // TRUCK, EXCAVATOR, BACKHOE
        public string Status { get; set; } = "";         // AVAILABLE, RESERVED, IN_USE, MAINTENANCE
        public string? Brand { get; set; }
        public string? Model { get; set; }
        public int? Year { get; set; }
        public int? Passengers { get; set; }
        public double? CargoKg { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public double? PricePerKm { get; set; }
    }

    public sealed class Talep
    {
        public Guid Id { get; set; }
        public Guid RequesterId { get; set; }
        public double PickUpLat { get; set; }
        public double PickUpLon { get; set; }
        public double? DropoffLat { get; set; }
        public double? DropoffLon { get; set; }
        public string VehicleType { get; set; } = "";
        public int? Passengers { get; set; }
        public DateTimeOffset StartAt { get; set; }
        public DateTimeOffset? EndAt { get; set; }
        public string Status { get; set; } = "";         // PENDING, MATCHED, RESERVED, CANCELLED
        public Guid? MatchedVehicleId { get; set; }
        public Guid? ReservationId { get; set; }
    }

    public sealed class Rezervasyon
    {
        public Guid Id { get; set; }
        public Guid RequestId { get; set; }
        public Guid VehicleId { get; set; }
        public Guid CompanyId { get; set; }
        public Guid CustomerId { get; set; }
        public string Status { get; set; } = "";         // PENDING, CONFIRMED, COMPLETED, CANCELLED
        public decimal? TotalPrice { get; set; }
        public DateTimeOffset StartAt { get; set; }
        public DateTimeOffset EndAt { get; set; }
        public DateTimeOffset? ConfirmedAt { get; set; }
        public DateTimeOffset? CompletedAt { get; set; }
        public DateTimeOffset? CancelledAt { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
    }

    public sealed class FirmaGirdisi
    {
        public string Name { get; set; } = "";
        public string TaxNumber { get; set; } = "";
        public string? Phone { get; set; }
        public string? Address { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
    }

    public sealed class AracGirdisi
    {
        public Guid CompanyId { get; set; }
        public string Plate { get; set; } = "";
        public string Type { get; set; } = "";
        public string? Brand { get; set; }
        public string? Model { get; set; }
        public int? Year { get; set; }
        public int? Passengers { get; set; }
        public double? CargoKg { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public double? PricePerKm { get; set; }
        public string? Status { get; set; }
    }

    public sealed class TalepGirdisi
    {
        public double PickUpLat { get; set; }
        public double PickUpLon { get; set; }
        public double? DropoffLat { get; set; }
        public double? DropoffLon { get; set; }
        public string VehicleType { get; set; } = "";
        public int? Passengers { get; set; }
        public DateTimeOffset StartAt { get; set; }
        public DateTimeOffset? EndAt { get; set; }
    }
}
