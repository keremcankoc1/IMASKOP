﻿using System;
using System.Windows.Forms;

namespace afad
{
    // AFAD'ın açtığı rezervasyonlar. AFAD (CUSTOMER) hesabı yalnızca iptal edebilir;
    // onaylama ve görevi tamamlama araç sahibi firmanın yetkisindedir (docs/API.md).
    public partial class AfadRezervasyonPenceresi : RezervasyonEkrani
    {
        private readonly string aktifKullaniciAdi;

        public AfadRezervasyonPenceresi() : this("")
        {
        }

        public AfadRezervasyonPenceresi(string kullaniciAdi)
        {
            InitializeComponent();

            aktifKullaniciAdi = string.IsNullOrWhiteSpace(kullaniciAdi)
                ? ApiIstemcisi.AktifKullanici?.Name ?? "Yetkili Personel"
                : kullaniciAdi.Trim();

            btnAfadGeriDon = Tema.Buton("Sevk Paneline Dön", Tema.IkincilButon, 165, 36);
            btnAfadGeriDon.Click += btnAfadGeriDon_Click;

            // POST /api/reservations/{id}/cancel
            btnRezervasyonIptal = Tema.Buton("Rezervasyonu İptal Et", Tema.Tehlike, 278, 40);
            btnRezervasyonIptal.Click += btnRezervasyonIptal_Click;

            EkraniKur(
                "AFAD - Rezervasyon ve Sevk Kayıtları",
                $"AFAD | {aktifKullaniciAdi}",
                new[] { btnAfadGeriDon },
                "Aktif Rezervasyon ve Sevk Listesi",
                new[] { btnRezervasyonIptal },
                "Rezervasyonu firma onaylar ve görev bitince firma tamamlandı olarak işaretler. Liste otomatik güncellenir.",
                sevkKonumuGoster: true);
        }

        protected override void ButonlariGuncelle(Rezervasyon? secili)
        {
            bool iptalEdilebilir = secili != null && (secili.Status == "PENDING" || secili.Status == "CONFIRMED");
            Tema.ButonDurumu(btnRezervasyonIptal, iptalEdilebilir);
        }

        private async void btnRezervasyonIptal_Click(object? sender, EventArgs e)
        {
            await RezervasyonIslemiYap(
                btnRezervasyonIptal,
                "Seçili rezervasyonu iptal etmek istediğinize emin misiniz?\n(Araç bu tarihler için yeniden müsait olacaktır.)",
                ApiIstemcisi.RezervasyonuIptalEt,
                "Rezervasyon iptal edildi.");
        }

        private void AfadRezervasyonPenceresi_Load(object? sender, EventArgs e) { }

        private void btnAfadGeriDon_Click(object? sender, EventArgs e)
        {
            Gec(new AfadUygulamaPenceresi(aktifKullaniciAdi));
        }
    }
}
