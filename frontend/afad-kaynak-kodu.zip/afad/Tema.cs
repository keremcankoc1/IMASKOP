using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace afad
{
    // Bütün pencerelerin ortak koyu kurumsal teması ve kontrol üreticileri
    public static class Tema
    {
        public static readonly Color ArkaPlan = Color.FromArgb(28, 30, 36);
        public static readonly Color Panel = Color.FromArgb(36, 39, 46);
        public static readonly Color GirdiKutusu = Color.FromArgb(45, 49, 58);
        public static readonly Color Kenarlik = Color.FromArgb(58, 62, 72);
        public static readonly Color AnaVurgu = Color.FromArgb(45, 115, 210);     // Kurumsal Mavi
        public static readonly Color Basari = Color.FromArgb(40, 135, 85);         // Mat Yeşil
        public static readonly Color Tehlike = Color.FromArgb(145, 50, 50);        // Mat Kırmızı
        public static readonly Color Amber = Color.FromArgb(215, 160, 60);         // Amber
        public static readonly Color IkincilButon = Color.FromArgb(52, 57, 68);
        public static readonly Color PasifButon = Color.FromArgb(70, 74, 84);
        public static readonly Color MetinAna = Color.FromArgb(235, 238, 242);
        public static readonly Color MetinSoluk = Color.FromArgb(160, 166, 178);

        public static void FormuHazirla(Form form, string baslik)
        {
            form.Controls.Clear();
            form.Text = baslik;
            form.Size = new Size(1160, 680);
            form.MinimumSize = new Size(980, 580);
            form.StartPosition = FormStartPosition.CenterScreen;
            form.BackColor = ArkaPlan;
            form.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);
        }

        public static Panel UstBarOlustur(string baslik)
        {
            Panel pnl = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Panel };
            pnl.Controls.Add(new Panel { Dock = DockStyle.Bottom, Height = 1, BackColor = Kenarlik });
            pnl.Controls.Add(new Label
            {
                Text = baslik,
                ForeColor = MetinAna,
                Font = new Font("Segoe UI Semibold", 12.5F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(20, 18)
            });
            return pnl;
        }

        // Üst barın sağına butonları sağdan sola dizer
        public static void UstBarButonlariEkle(Panel ustBar, params Button[] butonlar)
        {
            int sag = ustBar.Width - 20;
            foreach (Button btn in butonlar)
            {
                sag -= btn.Width;
                btn.Location = new Point(sag, 12);
                btn.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                ustBar.Controls.Add(btn);
                sag -= 10;
            }
        }

        public static Panel SolPanelOlustur(string baslik)
        {
            Panel pnl = new Panel { Dock = DockStyle.Left, Width = 320, BackColor = Panel, AutoScroll = true };
            pnl.Controls.Add(new Panel { Dock = DockStyle.Right, Width = 1, BackColor = Kenarlik });
            pnl.Controls.Add(new Label
            {
                Text = baslik,
                ForeColor = MetinAna,
                Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true
            });
            return pnl;
        }

        public static Button Buton(string metin, Color arkaPlan, int genislik, int yukseklik)
        {
            Button btn = new Button
            {
                Text = metin,
                Size = new Size(genislik, yukseklik),
                BackColor = arkaPlan,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold),
                Tag = arkaPlan
            };
            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = Color.FromArgb(70, 75, 88);
            return btn;
        }

        // Flat butonlarda Enabled=false arka planı değiştirmez; gri rengi elle veriyoruz
        public static void ButonDurumu(Button btn, bool aktif)
        {
            btn.Enabled = aktif;
            btn.BackColor = aktif && btn.Tag is Color renk ? renk : PasifButon;
            btn.Cursor = aktif ? Cursors.Hand : Cursors.Default;
        }

        public static Label AlanBasligi(string metin, int x, int y)
        {
            return new Label
            {
                Text = metin,
                ForeColor = MetinSoluk,
                Font = new Font("Segoe UI", 9F),
                Location = new Point(x, y),
                AutoSize = true
            };
        }

        public static Label DetayBasligi(string metin, int y)
        {
            return new Label
            {
                Text = metin,
                ForeColor = MetinSoluk,
                Font = new Font("Segoe UI", 8.5F),
                Location = new Point(12, y),
                AutoSize = true
            };
        }

        public static Label DetayDegeri(string metin, int y)
        {
            return new Label
            {
                Text = metin,
                ForeColor = MetinAna,
                Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold),
                Location = new Point(12, y),
                Size = new Size(254, 20),
                AutoEllipsis = true
            };
        }

        public static TextBox MetinKutusu(int x, int y, int genislik, string ipucu = "")
        {
            return new TextBox
            {
                Location = new Point(x, y),
                Width = genislik,
                Font = new Font("Segoe UI", 10F),
                BackColor = GirdiKutusu,
                ForeColor = MetinAna,
                BorderStyle = BorderStyle.FixedSingle,
                PlaceholderText = ipucu
            };
        }

        public static ComboBox SecimKutusu(int x, int y, int genislik)
        {
            return new ComboBox
            {
                Location = new Point(x, y),
                Width = genislik,
                Font = new Font("Segoe UI", 10F),
                BackColor = GirdiKutusu,
                ForeColor = MetinAna,
                FlatStyle = FlatStyle.Flat,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
        }

        public static NumericUpDown SayiKutusu(int x, int y, int genislik, decimal min, decimal max, int ondalik = 0)
        {
            return new NumericUpDown
            {
                Location = new Point(x, y),
                Width = genislik,
                Font = new Font("Segoe UI", 10F),
                BackColor = GirdiKutusu,
                ForeColor = MetinAna,
                BorderStyle = BorderStyle.FixedSingle,
                Minimum = min,
                Maximum = max,
                DecimalPlaces = ondalik,
                Increment = ondalik > 0 ? 0.01M : 1
            };
        }

        public static DateTimePicker TarihSecici(int x, int y, int genislik)
        {
            return new DateTimePicker
            {
                Location = new Point(x, y),
                Width = genislik,
                Font = new Font("Segoe UI", 10F),
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "dd.MM.yyyy HH:mm",
                CalendarMonthBackground = GirdiKutusu,
                CalendarForeColor = MetinAna
            };
        }

        public static DataGridView Tablo()
        {
            DataGridView dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Panel,
                BorderStyle = BorderStyle.FixedSingle,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                GridColor = Kenarlik,
                EnableHeadersVisualStyles = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                RowHeadersVisible = false
            };

            Color baslikRengi = Color.FromArgb(42, 46, 54);
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = baslikRengi;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = MetinSoluk;
            dgv.ColumnHeadersDefaultCellStyle.SelectionBackColor = baslikRengi;
            dgv.ColumnHeadersDefaultCellStyle.SelectionForeColor = MetinSoluk;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold);
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = 38;

            dgv.DefaultCellStyle.BackColor = Panel;
            dgv.DefaultCellStyle.ForeColor = MetinAna;
            dgv.DefaultCellStyle.Font = new Font("Segoe UI", 9.5F);
            dgv.DefaultCellStyle.Padding = new Padding(6, 0, 0, 0);
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(55, 68, 92);
            dgv.DefaultCellStyle.SelectionForeColor = Color.White;
            dgv.RowTemplate.Height = 36;

            // Veri bağlanınca ilk satır kendiliğinden seçilmesin; "Id" sütunu gizli kalsın
            dgv.DataBindingComplete += (s, e) =>
            {
                if (dgv.Columns.Contains("Id")) dgv.Columns["Id"]!.Visible = false;
            };
            return dgv;
        }

        // Tablonun üstündeki başlık şeridi; kayıt sayısı etiketini döndürür
        public static Panel TabloUstBar(string baslik, out Label sayacEtiketi)
        {
            Panel pnl = new Panel { Dock = DockStyle.Top, Height = 45 };
            Label lblBaslik = new Label
            {
                Text = baslik,
                ForeColor = MetinAna,
                Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(0, 10)
            };
            pnl.Controls.Add(lblBaslik);

            sayacEtiketi = new Label
            {
                Text = "",
                ForeColor = MetinSoluk,
                Font = new Font("Segoe UI", 9F),
                AutoSize = true,
                Location = new Point(lblBaslik.PreferredWidth + 8, 13)
            };
            pnl.Controls.Add(sayacEtiketi);
            return pnl;
        }

        public static Label DurumCubugu()
        {
            return new Label
            {
                Dock = DockStyle.Bottom,
                Height = 24,
                ForeColor = MetinSoluk,
                Font = new Font("Segoe UI", 8.5F),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(2, 0, 0, 0)
            };
        }

        public static void Hata(Exception ex)
        {
            string mesaj = ex is ApiHatasi ? ex.Message : "Beklenmeyen bir hata oluştu: " + ex.Message;
            MessageBox.Show(mesaj, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static void Uyari(string mesaj) =>
            MessageBox.Show(mesaj, "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        public static void Bilgi(string mesaj) =>
            MessageBox.Show(mesaj, "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    // Listeler sunucudan yenilenirken seçili satırın kaybolmaması için gizli "Id" sütunu üzerinden çalışır
    public static class TabloSecimi
    {
        public static Guid? SeciliId(DataGridView dgv)
        {
            if (dgv.SelectedRows.Count == 0 || !dgv.Columns.Contains("Id")) return null;
            return dgv.SelectedRows[0].Cells["Id"].Value is Guid id ? id : null;
        }

        public static void Sec(DataGridView dgv, Guid? id)
        {
            dgv.ClearSelection();
            if (id == null || !dgv.Columns.Contains("Id")) return;

            foreach (DataGridViewRow satir in dgv.Rows)
            {
                if (satir.Cells["Id"].Value is Guid satirId && satirId == id)
                {
                    satir.Selected = true;
                    dgv.CurrentCell = satir.Cells[dgv.Columns.GetFirstColumn(DataGridViewElementStates.Visible)!.Index];
                    return;
                }
            }
        }
    }

    // API'deki İngilizce kodların ekranda görünen Türkçe karşılıkları
    public static class Etiketler
    {
        public static readonly (string Kod, string Ad)[] AracTurleri =
        {
            ("TRUCK", "Kamyon"),
            ("EXCAVATOR", "Ekskavatör"),
            ("BACKHOE", "Kazıcı Yükleyici (Beko Loder)")
        };

        public static readonly (string Kod, string Ad)[] AracDurumlariSecilebilir =
        {
            ("AVAILABLE", "Müsait"),
            ("MAINTENANCE", "Bakımda"),
            ("IN_USE", "Kullanımda")
        };

        public static string AracTuru(string kod)
        {
            foreach (var t in AracTurleri)
                if (t.Kod == kod) return t.Ad;
            return kod;
        }

        public static string AracDurumu(string kod) => kod switch
        {
            "AVAILABLE" => "Müsait",
            "RESERVED" => "Rezerve",
            "IN_USE" => "Kullanımda",
            "MAINTENANCE" => "Bakımda",
            _ => kod
        };

        public const string Beklemede = "Firma Onayı Bekliyor";
        public const string Onaylandi = "Onaylandı";
        public const string Tamamlandi = "Tamamlandı";
        public const string IptalEdildi = "İptal Edildi";

        public static string RezervasyonDurumu(string kod) => kod switch
        {
            "PENDING" => Beklemede,
            "CONFIRMED" => Onaylandi,
            "COMPLETED" => Tamamlandi,
            "CANCELLED" => IptalEdildi,
            _ => kod
        };

        public static Color RezervasyonRengi(string kod) => kod switch
        {
            "PENDING" => Tema.Amber,
            "CONFIRMED" => Tema.AnaVurgu,
            "COMPLETED" => Tema.Basari,
            "CANCELLED" => Color.FromArgb(200, 90, 90),
            _ => Tema.MetinAna
        };

        public static string Zaman(DateTimeOffset zaman) => zaman.ToLocalTime().ToString("dd.MM.yyyy HH:mm");

        public static string KisaNo(Guid id) => id.ToString("N")[..8].ToUpperInvariant();

        public static string AracAdi(Arac a)
        {
            string marka = string.Join(" ", new[] { a.Brand, a.Model }).Trim();
            return string.IsNullOrEmpty(marka) ? a.Plate : $"{a.Plate} ({marka})";
        }
    }

    // API konumları enlem/boylam olarak tutuyor; kullanıcıya şehir adıyla seçtirip gösteriyoruz.
    // Koordinatlar şehir merkezlerinin yaklaşık değerleridir.
    public static class Sehirler
    {
        public static readonly (string Ad, double Enlem, double Boylam)[] Liste =
        {
            ("Adana", 37.00, 35.32),
            ("Adıyaman", 37.76, 38.28),
            ("Ankara", 39.93, 32.86),
            ("Antalya", 36.90, 30.70),
            ("Bursa", 40.19, 29.06),
            ("Denizli", 37.78, 29.09),
            ("Diyarbakır", 37.91, 40.24),
            ("Elazığ", 38.67, 39.22),
            ("Erzurum", 39.90, 41.27),
            ("Eskişehir", 39.78, 30.52),
            ("Gaziantep", 37.07, 37.38),
            ("Hatay", 36.20, 36.16),
            ("İstanbul", 41.01, 28.98),
            ("İzmir", 38.42, 27.14),
            ("Kahramanmaraş", 37.58, 36.94),
            ("Kayseri", 38.73, 35.48),
            ("Kocaeli", 40.77, 29.92),
            ("Konya", 37.87, 32.48),
            ("Malatya", 38.35, 38.31),
            ("Manisa", 38.61, 27.43),
            ("Mersin", 36.81, 34.64),
            ("Osmaniye", 37.07, 36.25),
            ("Sakarya", 40.78, 30.40),
            ("Samsun", 41.29, 36.33),
            ("Şanlıurfa", 37.16, 38.79),
            ("Trabzon", 41.00, 39.72),
            ("Van", 38.50, 43.38)
        };

        public const string ElleGir = "Koordinatı elle gir";

        // Koordinata en yakın şehri "≈ Ankara" şeklinde verir; 60 km'den uzaksa koordinatı yazar
        public static string Adi(double? enlem, double? boylam)
        {
            if (enlem == null || boylam == null) return "-";

            string enYakin = "";
            double enKisa = double.MaxValue;
            foreach (var s in Liste)
            {
                double mesafe = MesafeKm(enlem.Value, boylam.Value, s.Enlem, s.Boylam);
                if (mesafe < enKisa) { enKisa = mesafe; enYakin = s.Ad; }
            }

            return enKisa <= 60
                ? (enKisa < 5 ? enYakin : "≈ " + enYakin)
                : $"{enlem.Value:0.00}, {boylam.Value:0.00}";
        }

        public static double MesafeKm(double enlem1, double boylam1, double enlem2, double boylam2)
        {
            double r = 6371;
            double dEnlem = (enlem2 - enlem1) * Math.PI / 180;
            double dBoylam = (boylam2 - boylam1) * Math.PI / 180;
            double a = Math.Sin(dEnlem / 2) * Math.Sin(dEnlem / 2) +
                       Math.Cos(enlem1 * Math.PI / 180) * Math.Cos(enlem2 * Math.PI / 180) *
                       Math.Sin(dBoylam / 2) * Math.Sin(dBoylam / 2);
            return r * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
        }

        // Şehir listesi + "elle gir" seçeneği, seçilen şehrin koordinatlarını iki sayı kutusuna yazar
        public static void SecimKutusunuBagla(ComboBox cmb, NumericUpDown nudEnlem, NumericUpDown nudBoylam, string varsayilan = "Ankara")
        {
            cmb.Items.Clear();
            foreach (var s in Liste) cmb.Items.Add(s.Ad);
            cmb.Items.Add(ElleGir);

            cmb.SelectedIndexChanged += (s, e) =>
            {
                bool elle = cmb.SelectedItem?.ToString() == ElleGir;
                nudEnlem.Enabled = elle;
                nudBoylam.Enabled = elle;
                if (elle) return;

                foreach (var sehir in Liste)
                {
                    if (sehir.Ad == cmb.SelectedItem?.ToString())
                    {
                        nudEnlem.Value = (decimal)sehir.Enlem;
                        nudBoylam.Value = (decimal)sehir.Boylam;
                        break;
                    }
                }
            };

            cmb.SelectedItem = varsayilan;
        }
    }
}
