using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace afad
{
    // API'nin döndürdüğü {"error":"kod"} hatalarını Türkçe mesajla taşır
    public sealed class ApiHatasi : Exception
    {
        public int HttpDurumu { get; }
        public string Kod { get; }

        public ApiHatasi(int httpDurumu, string kod) : base(ApiIstemcisi.HataMesaji(httpDurumu, kod))
        {
            HttpDurumu = httpDurumu;
            Kod = kod;
        }
    }

    // IMASKOP backend'i ile konuşan tek nokta. Oturum (token ve giriş yapan kullanıcı) burada tutulur.
    public static class ApiIstemcisi
    {
        // Sunucu adresi; exe'nin yanındaki "api-adresi.txt" dosyasıyla değiştirilebilir
        public const string VarsayilanAdres = "https://imaskop-api.onrender.com";

        public static string TemelAdres { get; }
        public static string? Token { get; private set; }
        public static Kullanici? AktifKullanici { get; private set; }

        private static readonly HttpClient http;

        private static readonly JsonSerializerOptions jsonAyarlari = new()
        {
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };

        static ApiIstemcisi()
        {
            TemelAdres = AdresiBelirle();
            http = new HttpClient
            {
                BaseAddress = new Uri(TemelAdres + "/"),
                // Render'ın ücretsiz sunucusu uykudan uyanırken ilk istek bir dakikaya kadar sürebilir
                Timeout = TimeSpan.FromSeconds(90)
            };
        }

        private static string AdresiBelirle()
        {
            string adres = VarsayilanAdres;
            try
            {
                string dosya = Path.Combine(AppContext.BaseDirectory, "api-adresi.txt");
                if (File.Exists(dosya))
                {
                    string okunan = File.ReadAllText(dosya).Trim();
                    if (!string.IsNullOrEmpty(okunan)) adres = okunan;
                }
            }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }

            // "https://.../api/" şeklinde yazılmışsa kök adrese indir
            adres = adres.TrimEnd('/');
            if (adres.EndsWith("/api", StringComparison.OrdinalIgnoreCase))
                adres = adres[..^4];
            return adres;
        }

        // GET /health: sunucu ve veritabanı ayakta mı? (Render'da uyuyan sunucuyu da uyandırır)
        public static async Task<bool> SunucuHazirMi()
        {
            try
            {
                var yanit = await Gonder<Dictionary<string, string>>(HttpMethod.Get, "health");
                return yanit.TryGetValue("status", out var durum) && durum == "ok";
            }
            catch (ApiHatasi)
            {
                return false;
            }
        }

        // ================= Oturum =================

        public static async Task<Kullanici> GirisYap(string email, string parola)
        {
            var yanit = await Gonder<GirisYaniti>(HttpMethod.Post, "api/auth/login", new { email, password = parola });
            Token = yanit.AccessToken;
            AktifKullanici = yanit.User;
            return yanit.User;
        }

        // Kayıt API'si yalnızca firma (COMPANY) hesabı açar
        public static Task<Kullanici> FirmaHesabiAc(string adSoyad, string email, string parola)
        {
            return Gonder<Kullanici>(HttpMethod.Post, "api/auth/register", new { email, password = parola, name = adSoyad, role = "COMPANY" });
        }

        public static async Task<Kullanici> BilgilerimiYenile()
        {
            AktifKullanici = await Gonder<Kullanici>(HttpMethod.Get, "api/me");
            return AktifKullanici;
        }

        public static void OturumuKapat()
        {
            Token = null;
            AktifKullanici = null;
        }

        // ================= Firma ve araçlar =================

        public static Task<Firma> FirmaOlustur(FirmaGirdisi girdi) =>
            Gonder<Firma>(HttpMethod.Post, "api/companies", girdi);

        public static Task<Arac> AracEkle(AracGirdisi girdi) =>
            Gonder<Arac>(HttpMethod.Post, "api/vehicles", girdi);

        // Firma hesabı yalnızca kendi araçlarını, AFAD bütün araçları görür.
        // Başlangıç ve bitiş verilirse yalnızca o aralıkta müsait araçlar döner.
        public static Task<List<Arac>> AraclariGetir(string? tur = null, DateTimeOffset? baslangic = null, DateTimeOffset? bitis = null)
        {
            var parametreler = new List<string>();
            if (!string.IsNullOrEmpty(tur)) parametreler.Add("type=" + Uri.EscapeDataString(tur));
            if (baslangic.HasValue && bitis.HasValue)
            {
                parametreler.Add("start_at=" + Uri.EscapeDataString(ZamanMetni(baslangic.Value)));
                parametreler.Add("end_at=" + Uri.EscapeDataString(ZamanMetni(bitis.Value)));
            }

            string yol = "api/vehicles" + (parametreler.Count > 0 ? "?" + string.Join("&", parametreler) : "");
            return Gonder<List<Arac>>(HttpMethod.Get, yol);
        }

        // ================= Talep -> eşleştirme -> rezervasyon (AFAD) =================

        public static Task<Talep> TalepOlustur(TalepGirdisi girdi) =>
            Gonder<Talep>(HttpMethod.Post, "api/requests", girdi);

        public static Task<List<Talep>> TalepleriGetir() =>
            Gonder<List<Talep>>(HttpMethod.Get, "api/requests");

        public static Task<Talep> TalebiEslestir(Guid talepId, Guid aracId) =>
            Gonder<Talep>(HttpMethod.Post, $"api/requests/{talepId}/match", new { vehicle_id = aracId });

        public static Task<Rezervasyon> RezervasyonOlustur(Guid talepId, Guid aracId) =>
            Gonder<Rezervasyon>(HttpMethod.Post, "api/reservations", new { request_id = talepId, vehicle_id = aracId });

        // ================= Rezervasyonlar =================

        public static Task<List<Rezervasyon>> RezervasyonlariGetir() =>
            Gonder<List<Rezervasyon>>(HttpMethod.Get, "api/reservations");

        public static Task<Rezervasyon> RezervasyonuOnayla(Guid id) => RezervasyonIslemi(id, "confirm");
        public static Task<Rezervasyon> RezervasyonuTamamla(Guid id) => RezervasyonIslemi(id, "complete");
        public static Task<Rezervasyon> RezervasyonuIptalEt(Guid id) => RezervasyonIslemi(id, "cancel");

        private static Task<Rezervasyon> RezervasyonIslemi(Guid id, string islem) =>
            Gonder<Rezervasyon>(HttpMethod.Post, $"api/reservations/{id}/{islem}");

        // ================= Ortak istek altyapısı =================

        // API RFC3339 bekliyor: 2026-11-01T10:00:00+03:00 (saniye altı gönderilmez)
        public static string ZamanMetni(DateTimeOffset zaman) =>
            zaman.ToString("yyyy-MM-dd'T'HH:mm:sszzz", System.Globalization.CultureInfo.InvariantCulture);

        private static async Task<T> Gonder<T>(HttpMethod metot, string yol, object? govde = null)
        {
            using var istek = new HttpRequestMessage(metot, yol);
            if (Token != null)
                istek.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Token);
            if (govde != null)
                istek.Content = JsonContent.Create(govde, govde.GetType(), options: jsonAyarlari);

            HttpResponseMessage yanit;
            try
            {
                yanit = await http.SendAsync(istek);
            }
            catch (TaskCanceledException)
            {
                throw new ApiHatasi(0, "baglanti_zaman_asimi");
            }
            catch (HttpRequestException)
            {
                throw new ApiHatasi(0, "baglanti_yok");
            }

            using (yanit)
            {
                if (!yanit.IsSuccessStatusCode)
                {
                    string kod = "";
                    if (yanit.Content.Headers.ContentType?.MediaType == "application/json")
                    {
                        try
                        {
                            var hata = await yanit.Content.ReadFromJsonAsync<Dictionary<string, string>>(jsonAyarlari);
                            if (hata != null && hata.TryGetValue("error", out var k)) kod = k;
                        }
                        catch (JsonException) { }
                    }

                    // Süresi dolan token: oturum geçersiz
                    if ((int)yanit.StatusCode == 401 && kod != "invalid_credentials")
                        OturumuKapat();

                    throw new ApiHatasi((int)yanit.StatusCode, kod);
                }

                var sonuc = await yanit.Content.ReadFromJsonAsync<T>(jsonAyarlari);
                return sonuc ?? throw new ApiHatasi((int)yanit.StatusCode, "bos_yanit");
            }
        }

        public static string HataMesaji(int httpDurumu, string kod)
        {
            switch (kod)
            {
                case "baglanti_yok": return $"Sunucuya bağlanılamadı ({TemelAdres}). İnternet bağlantınızı ve sunucu adresini kontrol ediniz.";
                case "baglanti_zaman_asimi": return "Sunucu zamanında yanıt vermedi. Sunucu uykudan uyanıyor olabilir, birkaç saniye sonra tekrar deneyiniz.";
                case "invalid_credentials": return "E-posta veya parola hatalı.";
                case "invalid_credentials_fields": return "Bilgiler geçersiz. E-posta geçerli olmalı, parola 12-72 karakter olmalıdır.";
                case "bearer_token_required":
                case "invalid_token": return "Oturumunuzun süresi doldu. Lütfen tekrar giriş yapınız.";
                case "forbidden": return "Bu işlem için yetkiniz yok.";
                case "not_found": return "Kayıt bulunamadı.";
                case "rate_limited": return "Çok fazla deneme yapıldı. Lütfen bir dakika sonra tekrar deneyiniz.";
                case "duplicate_record": return "Bu kayıt zaten mevcut (aynı e-posta veya plaka daha önce kaydedilmiş olabilir).";
                case "company_already_exists": return "Bu hesaba ait bir firma zaten kayıtlı.";
                case "invalid_company": return "Firma bilgileri geçersiz. Firma adı ve vergi numarası zorunludur.";
                case "invalid_vehicle": return "Araç bilgileri geçersiz. Plaka ve araç türü zorunludur.";
                case "invalid_request": return "Talep bilgileri geçersiz. Konum, araç türü ve tarihleri kontrol ediniz.";
                case "invalid_time_range": return "Bitiş zamanı başlangıçtan sonra olmalıdır.";
                case "reservation_overlap": return "Seçilen araç bu tarihlerde başka bir rezervasyonda. Listeyi yenileyip başka bir araç seçiniz.";
                case "vehicle_not_eligible": return "Seçilen araç bu talep için uygun değil (tür, durum veya kapasite uyuşmuyor).";
                case "request_not_open": return "Bu talep artık açık değil.";
                case "request_must_match_vehicle": return "Talep ile araç eşleştirilemedi.";
                case "invalid_reservation_transition": return "Rezervasyonun mevcut durumunda bu işlem yapılamaz. Liste güncellenmiş olabilir.";
                case "vehicle_has_active_reservations": return "Aracın aktif rezervasyonu olduğu için güncellenemez.";
                case "retry_transaction": return "İşlem çakıştı. Lütfen tekrar deneyiniz.";
                case "database_unavailable": return "Sunucunun veritabanına şu an ulaşılamıyor. Lütfen daha sonra tekrar deneyiniz.";
                case "request_timeout": return "Sunucu işlemi zamanında tamamlayamadı. Lütfen tekrar deneyiniz.";
                case "internal_error": return "Sunucuda beklenmeyen bir hata oluştu.";
            }

            if (httpDurumu == 404) return "İstenen adres sunucuda bulunamadı. Sunucu adresini kontrol ediniz.";
            return $"Sunucu hatası ({httpDurumu}{(string.IsNullOrEmpty(kod) ? "" : ", " + kod)}).";
        }
    }
}
