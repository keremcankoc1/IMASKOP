﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace afad
{
    public partial class UygulamaLoginPenceresi : Form
    {
        private Label lblSunucuDurumu = null!;
        private Button btnFirmaKaydi = null!;

        public UygulamaLoginPenceresi()
        {
            InitializeComponent();
            SadeArayuzuOlustur();
        }

        private void SadeArayuzuOlustur()
        {
            Controls.Clear();

            Text = "IMASKOP - Sisteme Giriş";
            ClientSize = new Size(440, 520);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Tema.ArkaPlan;
            Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);

            Panel pnlKart = new Panel
            {
                Location = new Point(40, 36),
                Size = new Size(360, 440),
                BackColor = Tema.Panel
            };
            Controls.Add(pnlKart);

            pnlKart.Controls.Add(new Label
            {
                Text = "IMASKOP",
                ForeColor = Tema.MetinAna,
                Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(28, 28)
            });
            pnlKart.Controls.Add(new Label
            {
                Text = "AFAD Araç Sevk ve Rezervasyon Sistemi",
                ForeColor = Tema.MetinSoluk,
                Font = new Font("Segoe UI", 9F),
                AutoSize = true,
                Location = new Point(30, 66)
            });

            pnlKart.Controls.Add(Tema.AlanBasligi("E-posta", 28, 112));
            txtKullaniciAdi = Tema.MetinKutusu(28, 134, 304, "ornek@kurum.gov.tr");
            pnlKart.Controls.Add(txtKullaniciAdi);

            pnlKart.Controls.Add(Tema.AlanBasligi("Parola", 28, 176));
            txtSifre = Tema.MetinKutusu(28, 198, 304);
            txtSifre.UseSystemPasswordChar = true;
            pnlKart.Controls.Add(txtSifre);

            btnGirisYap = Tema.Buton("Giriş Yap", Tema.AnaVurgu, 304, 42);
            btnGirisYap.Location = new Point(28, 252);
            btnGirisYap.Click += btnGirisYap_Click;
            pnlKart.Controls.Add(btnGirisYap);
            AcceptButton = btnGirisYap;

            pnlKart.Controls.Add(new Label
            {
                Text = "Lojistik firması mısınız? Hesabınız yoksa oluşturun:",
                ForeColor = Tema.MetinSoluk,
                Font = new Font("Segoe UI", 8.5F),
                AutoSize = true,
                Location = new Point(28, 318)
            });

            btnFirmaKaydi = Tema.Buton("Firma Hesabı Oluştur", Tema.IkincilButon, 304, 36);
            btnFirmaKaydi.Location = new Point(28, 340);
            btnFirmaKaydi.Click += BtnFirmaKaydi_Click;
            pnlKart.Controls.Add(btnFirmaKaydi);

            lblSunucuDurumu = new Label
            {
                Text = "Sunucuya bağlanılıyor...",
                ForeColor = Tema.MetinSoluk,
                Font = new Font("Segoe UI", 8.5F),
                Location = new Point(28, 396),
                Size = new Size(304, 34),
                AutoEllipsis = true
            };
            pnlKart.Controls.Add(lblSunucuDurumu);

            Shown += async (s, e) => await SunucuyuKontrolEt();
        }

        // Render'ın ücretsiz sunucusu uykudaysa açılışta uyandırır, kullanıcı girişe kadar hazır olur
        private async Task SunucuyuKontrolEt()
        {
            lblSunucuDurumu.ForeColor = Tema.MetinSoluk;
            lblSunucuDurumu.Text = "Sunucuya bağlanılıyor... (ilk açılışta 1 dakika sürebilir)";

            bool hazir = await ApiIstemcisi.SunucuHazirMi();
            if (IsDisposed) return;

            lblSunucuDurumu.ForeColor = hazir ? Tema.Basari : Color.FromArgb(220, 110, 110);
            lblSunucuDurumu.Text = hazir
                ? "● Sunucu hazır  (" + new Uri(ApiIstemcisi.TemelAdres).Host + ")"
                : "● Sunucuya ulaşılamadı: " + ApiIstemcisi.TemelAdres;
        }

        // Çıkış yapıldığında giriş ekranı yeniden kullanılır
        public void EkraniSifirla()
        {
            txtSifre.Clear();
            Tema.ButonDurumu(btnGirisYap, true);
            Tema.ButonDurumu(btnFirmaKaydi, true);
        }

        private void UygulamaLoginPenceresi_Load(object? sender, EventArgs e) { }

        private async void btnGirisYap_Click(object? sender, EventArgs e)
        {
            string email = txtKullaniciAdi.Text.Trim();
            string parola = txtSifre.Text;

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrEmpty(parola))
            {
                Tema.Uyari("Lütfen e-posta ve parolanızı giriniz.");
                return;
            }

            Tema.ButonDurumu(btnGirisYap, false);
            btnGirisYap.Text = "Giriş yapılıyor...";
            UseWaitCursor = true;
            try
            {
                Kullanici kullanici = await ApiIstemcisi.GirisYap(email, parola);
                PaneleGec(kullanici);
            }
            catch (Exception ex)
            {
                Tema.Hata(ex);
            }
            finally
            {
                UseWaitCursor = false;
                btnGirisYap.Text = "Giriş Yap";
                Tema.ButonDurumu(btnGirisYap, true);
            }
        }

        private void PaneleGec(Kullanici kullanici)
        {
            Form panel;
            if (kullanici.Role == "COMPANY")
            {
                // İlk girişte firma bilgileri henüz yoksa önce firma kaydı yapılır
                if (kullanici.CompanyId == null)
                {
                    using var firmaBilgi = new FirmaBilgiPenceresi();
                    if (firmaBilgi.ShowDialog(this) != DialogResult.OK || ApiIstemcisi.AktifKullanici?.CompanyId == null)
                    {
                        ApiIstemcisi.OturumuKapat();
                        return;
                    }
                }
                panel = new FirmaUygulamaPenceresi();
            }
            else
            {
                // CUSTOMER (AFAD) ve ADMIN hesapları AFAD paneline girer
                panel = new AfadUygulamaPenceresi(kullanici.Name);
            }

            txtSifre.Clear();
            panel.Show();
            Hide();
        }

        private void BtnFirmaKaydi_Click(object? sender, EventArgs e)
        {
            using var kayit = new FirmaKayitPenceresi();
            if (kayit.ShowDialog(this) != DialogResult.OK) return;

            // Kayıttan sonra aynı bilgilerle otomatik giriş yap
            txtKullaniciAdi.Text = kayit.Email;
            txtSifre.Text = kayit.Parola;
            btnGirisYap_Click(btnGirisYap, EventArgs.Empty);
        }
    }
}
